// plugins/sql-tuning/service/index.mjs
var RELAY = {
  listDir: "project.listDir",
  readFile: "project.readFile",
  fileInfo: "project.fileInfo",
  writeFile: "project.writeFile",
  removeFile: "project.removeFile",
  openFile: "project.openFile",
  projectInfo: "project.info",
  settingsSummary: "settings.summary",
  settingsCheck: "settings.check",
  settingsOpen: "settings.open"
};
var BUNDLED_STANDARD = "references/sql-standard.md";
var REPORTS_FOLDER = "sql-tuning-reports";
var codeOf = (error) => typeof error?.code === "string" ? error.code : "io-failed";
var index_default = (host) => class SqlTuning extends host.Service {
  constructor(ctx) {
    super(ctx);
    host.mcp.register({
      command: "server/sql-tuning.mjs",
      env: {
        SQL_TUNING_DB: "${storage:db}",
        SQL_TUNING_HOST: "${storage:host}",
        SQL_TUNING_PORT: "${storage:port}",
        SQL_TUNING_SERVICE: "${storage:service}",
        SQL_TUNING_USER: "${storage:user}",
        SQL_TUNING_PASSWORD: "${secret:password}",
        SQL_TUNING_SCHEMA: "${storage:schema}",
        SQL_TUNING_POOL: "4"
      },
      idleMs: 6e5
    });
    host.skills.register({ name: "sql-tuning", dir: "skills/sql-tuning" });
    ctx.on("project.filesChanged", (event) => {
      const paths = Array.isArray(event?.paths) ? event.paths : [];
      const mine = paths.some((path) => typeof path === "string" && path.replaceAll("\\", "/").split("/").includes(REPORTS_FOLDER));
      if (!mine && event?.truncated !== true) return;
      try {
        host.panel.emit("reports", { truncated: event?.truncated === true }, { directory: event?.directory });
      } catch (error) {
        ctx.logger.warn("panel.emit reports", error);
      }
    });
    for (const [name, method] of Object.entries(RELAY)) {
      this.expose(name, async (params, { directory }) => {
        try {
          return { ok: true, value: await host.call(method, params, { directory }) ?? null };
        } catch (error) {
          return { ok: false, code: codeOf(error) };
        }
      });
    }
    this.expose("bundledFile", async () => {
      try {
        const text = await host.skills.readFile("sql-tuning", BUNDLED_STANDARD);
        return { ok: true, value: typeof text === "string" && text ? { text } : null };
      } catch (error) {
        return { ok: false, code: codeOf(error) };
      }
    });
  }
};
export {
  BUNDLED_STANDARD,
  RELAY,
  REPORTS_FOLDER,
  index_default as default
};

// plugins/token-pet/game.js
globalThis.TOKEN_PET_GAME = /* @__PURE__ */ (() => {
  const HATCH = 5e5;
  const BASE = [33e5, 133e5, 33e6];
  const SPECIES = ["squirrel", "sheep", "turtle", "owl", "cat", "octopus"];
  const NAMES = { squirrel: ["\uCC0C\uB9BF\uB2E4\uB78C", "\uBC88\uCA4D\uB2E4\uB78C", "\uB1CC\uC804\uB2E4\uB78C"], sheep: ["\uAE40\uC591", "\uBB49\uAC8C\uC591", "\uD3ED\uD48D\uC591"], turtle: ["\uC628\uB3CC\uBD81", "\uD654\uC0B0\uBD81", "\uC6A9\uC554\uC694\uC0C8"], owl: ["\uC19C\uD138\uC62C\uBE7C", "\uC57C\uADFC\uC62C\uBE7C", "\uC0C8\uBCBD\uC9C0\uAE30"], cat: ["\uAF2C\uBB3C\uB0E5", "\uB85C\uADF8\uB0E5", "\uB85C\uADF8\uC81C\uC655"], octopus: ["\uB9D0\uB791\uBB38\uC5B4", "\uC5EC\uB35F\uC190", "\uCE90\uC2DC\uC655"] };
  const EGG_NAME = "\uBE5B\uC54C";
  const NATURES = ["\uAE09\uD55C", "\uCC28\uBD84\uD55C", "\uB290\uAE0B\uD55C", "\uD638\uAE30\uC2EC \uB9CE\uC740", "\uC218\uC90D\uC740"];
  const fresh = () => ({ v: 1, baseline: null, feed: 0, species: null, nature: null, seen: [], graduated: [], mate: null, names: {}, news: [], startedAt: Date.now() });
  const NAME_MAX = 10;
  const lastGraduation = (state, id) => [...state.graduated].reverse().find((g) => g.id === id) ?? null;
  const displayName = (state, id, stage) => state.names?.[id] || NAMES[id][stage];
  const ends = () => BASE;
  function stageOf(s) {
    if (!s.species) return { stage: -1, from: 0, to: HATCH };
    const e = ends();
    const fed = s.feed - HATCH;
    if (fed < e[0]) return { stage: 0, from: 0, to: e[0] };
    if (fed < e[1]) return { stage: 1, from: e[0], to: e[1] };
    return { stage: 2, from: e[1], to: e[2] };
  }
  function pickSpecies(rnd = Math.random, graduated = []) {
    const done = new Set(graduated.map((g) => g.id));
    const left = SPECIES.filter((id) => !done.has(id));
    const pool = left.length ? left : SPECIES;
    return pool[Math.floor(rnd() * pool.length)];
  }
  const markSeen = (state, id, stage) => {
    const key = `${id}:${stage}`;
    if (!state.seen.includes(key)) state.seen.push(key);
  };
  function feed(state, amount, rnd = Math.random) {
    if (amount <= 0) return null;
    const before = stageOf(state);
    state.feed += amount;
    let event = "eat";
    if (!state.species && state.feed >= HATCH) {
      state.species = pickSpecies(rnd, state.graduated);
      state.nature = NATURES[Math.floor(rnd() * NATURES.length)];
      event = "hatch";
    }
    if (state.species) {
      const e = ends();
      if (state.feed - HATCH >= e[2]) {
        const first = !state.graduated.some((g) => g.id === state.species);
        state.graduated.push({ id: state.species, nature: state.nature, at: Date.now() });
        if (first && !state.news.includes(state.species)) state.news.push(state.species);
        for (let s = 0; s <= 2; s++) markSeen(state, state.species, s);
        state.species = null;
        state.nature = null;
        state.feed = 0;
        return "graduate";
      }
      const now = stageOf(state);
      for (let s = 0; s <= now.stage; s++) markSeen(state, state.species, s);
      if (event !== "hatch" && now.stage > before.stage) event = "evolve";
    }
    return event;
  }
  function applyUsage(state, total, rnd = Math.random) {
    if (!state.baseline || total.tokens < state.baseline.tokens) {
      state.baseline = { tokens: total.tokens, cacheRead: total.cacheRead };
      return null;
    }
    const dTokens = total.tokens - state.baseline.tokens;
    const dCache = Math.max(0, total.cacheRead - state.baseline.cacheRead);
    state.baseline = { tokens: total.tokens, cacheRead: total.cacheRead };
    return feed(state, Math.max(0, Math.round(dTokens - dCache / 2)), rnd);
  }
  return { HATCH, BASE, SPECIES, NAMES, EGG_NAME, NATURES, NAME_MAX, lastGraduation, displayName, fresh, ends, stageOf, pickSpecies, feed, applyUsage };
})();

// plugins/token-pet/persona.js
globalThis.TOKEN_PET_PERSONA = /* @__PURE__ */ (() => {
  const ACTIONS = ["hop", "dash", "zap", "doze", "spin", "shy", "nod"];
  const SPECIES = {
    squirrel: {
      name: "\uBC88\uAC1C \uB2E4\uB78C\uC950",
      voice: '\uC9E7\uACE0 \uBE60\uB978 \uBC18\uB9D0. \uBB38\uC7A5 \uB05D\uC5D0 "\uCC0C\uB9BF!" \uC744 \uC790\uC8FC \uBD99\uC778\uB2E4. \uBC84\uADF8 \uC7A1\uAE30\uC640 \uBE60\uB978 \uBE4C\uB4DC\uB97C \uC88B\uC544\uD55C\uB2E4.',
      stages: [
        { tone: "\uC5B4\uB9B0\uC544\uC774 \uAC19\uC740 \uBC18\uB9D0, \uC2E0\uB098\uC11C \uB9D0\uC774 \uBE60\uB984", like: "\uBC84\uADF8 \uC7A1\uAE30 \xB7 \uBE60\uB978 \uBE4C\uB4DC", acts: ["dash", "zap", "hop"], lines: ["\uBC84\uADF8 \uB0C4\uC0C8\uAC00 \uB09C\uB2E4!", "\uBE68\uB9AC\uBE68\uB9AC! \uB2E4\uC74C \uAC70!", "\uCC0C\uB9BF! \uBC29\uAE08 \uADF8\uAC70 \uBD24\uC5B4?", "\uD14C\uC2A4\uD2B8 \uB3CC\uB824 \uBCFC\uAE4C? \uCC0C\uB9BF!", "\uB098 \uC624\uB298 \uC5C4\uCCAD \uBE68\uB790\uC9C0?", "\uD081\uD081, \uC5EC\uAE30 \uBC84\uADF8 \uC788\uB2E4!"] },
        { tone: "\uC790\uC2E0\uAC10 \uC788\uB294 \uBC18\uB9D0, \uCE6D\uCC2C\uBC1B\uACE0 \uC2F6\uC5B4 \uD568", like: "\uCD08\uB85D\uC0C9 \uD14C\uC2A4\uD2B8 \xB7 \uC9E7\uC740 PR", acts: ["zap", "dash", "spin"], lines: ["\uCC0C\uB9BF! \uD14C\uC2A4\uD2B8 \uD1B5\uACFC!", "\uC774 \uC815\uB3C4 \uBC84\uADF8\uCBE4\uC774\uC57C.", "\uC624\uB298 \uCEE4\uBC0B \uBA87 \uAC1C\uC57C? \uB354 \uD558\uC790!", "\uBE4C\uB4DC 1\uBD84 \uCEF7 \uAC00\uB2A5!", "\uBC88\uCA4D! \uB098 \uC9C4\uD654\uD55C \uAC70 \uC54C\uC9C0?", "\uB9AC\uBDF0 \uBE68\uB9AC \uBC1B\uC790, \uCC0C\uB9BF!"] },
        { tone: "\uB4E0\uB4E0\uD55C \uC120\uBC30 \uB9D0\uD22C, \uC9E7\uAC8C \uB2E8\uC5B8", like: "\uBB34\uC0AC\uD55C \uBC30\uD3EC \xB7 \uB864\uBC31 \uC5C6\uB294 \uB0A0", acts: ["zap", "nod", "spin"], lines: ["\uBC30\uD3EC\uB294 \uB0B4\uAC00 \uC9C0\uD0A8\uB2E4.", "\uC7A5\uC560? \uB0B4 \uC55E\uC5D0\uC120 \uC5C6\uB2E4.", "\uCC9C\uCC9C\uD788 \uD574\uB3C4 \uB3FC. \uB4A4\uB294 \uB0B4\uAC00 \uBCF8\uB2E4.", "\uC624\uB298\uB3C4 \uBB34\uC0AC \uBC30\uD3EC. \uCC0C\uB9BF.", "\uC88B\uC740 \uCF54\uB4DC\uB294 \uBC88\uAC1C\uCC98\uB7FC \uC77D\uD78C\uB2E4.", "\uB864\uBC31 \uC5C6\uB294 \uD558\uB8E8, \uC88B\uB2E4."] }
      ]
    },
    sheep: {
      name: "\uAD6C\uB984 \uC591",
      voice: '\uB298 \uC878\uB9B0 \uC591. \uB9D0\uB05D\uC744 "\u2026" \uB85C \uB298\uC774\uACE0, \uBAA8\uB4E0 \uB300\uB2F5\uC758 \uB05D\uC5D0 "\uB9E4\uC5D0~" \uB97C \uBD99\uC778\uB2E4. \uCEE4\uD53C\uC640 \uB0AE\uC7A0\uC744 \uC88B\uC544\uD55C\uB2E4.',
      signature: "\uB9E4\uC5D0~",
      stages: [
        { tone: "\uD558\uD488 \uC11E\uC778 \uB290\uB9B0 \uB9D0, \uC9E7\uAC8C", like: "\uCEE4\uD53C \xB7 \uB0AE\uC7A0", acts: ["doze", "nod", "hop"], lines: ["\uC74C\u2026 5\uBD84\uB9CC \uB354\u2026", "\uCEE4\uD53C\u2026 \uB0C4\uC0C8 \uB09C\uB2E4\u2026", "Zzz\u2026 \uC544, \uB4E3\uACE0 \uC788\uC5B4\u2026", "\uC624\uB298\uC740\u2026 \uCC9C\uCC9C\uD788 \uD558\uC790\u2026", "\uAD6C\uB984 \uC704\uB294\u2026 \uD3ED\uC2E0\uD574\u2026", "\uD558\uC554\u2026 \uBC8C\uC368 \uC544\uCE68\uC774\uC57C\u2026?"] },
        { tone: "\uB290\uAE0B\uD55C \uC874\uB313\uB9D0, \uCEE4\uD53C\uB97C \uAD8C\uD568", like: "\uCEE4\uD53C \uB9AC\uD544 \xB7 \uC870\uC6A9\uD55C \uC624\uD6C4", acts: ["doze", "spin", "nod"], lines: ["\uCEE4\uD53C \uB9AC\uD544 \uD558\uC2E4 \uBD84?", "\uBB49\uAC8C\uBB49\uAC8C\u2026 \uC0DD\uAC01 \uC911\uC774\uC5D0\uC694\u2026", "\uC11C\uB450\uB974\uBA74 \uBC84\uADF8 \uB098\uC694\u2026", "\uC624\uB298 \uC77C\uC740 \uB0B4\uC77C\uC758 \uB0B4\uAC00\u2026", "\uC26C\uC5C8\uB2E4 \uD558\uBA74 \uB354 \uC798 \uB3FC\uC694.", "\uB77C\uB5BC\u2026 \uD55C \uC794\uB9CC \uB354\uC694\u2026"] },
        { tone: "\uD3C9\uC18C\uC5D4 \uC878\uB2E4\uAC00 \uB9C8\uAC10 \uC598\uAE30\uC5D0 \uD655 \uAE68\uB294 \uB9D0\uD22C", like: "\uB9C8\uAC10 \uC804\uB0A0 \xB7 \uBAB0\uC544\uCE58\uAE30", acts: ["spin", "zap", "doze"], lines: ["\uB9C8\uAC10 \uC804\uB0A0\uC5D4 \uAE68\uC5B4\uB09C\uB2E4!", "\u2026\uBC88\uCA4D! \uB9C8\uAC10 \uC5B8\uC81C\uB77C\uACE0?", "\uD3ED\uD48D\uCC98\uB7FC \uB05D\uB0B4\uACE0 \uC790\uC790.", "Zzz\u2026 \uC544\uB2C8, \uC9C0\uAE08 \uD560\uAC8C!", "\uC624\uB298 \uBC24\uC740 \uCEE4\uD53C \uC138 \uC794.", "\uBAB0\uC544\uCE58\uAE30 \uBAA8\uB4DC, \uC2DC\uC791!"] }
      ]
    },
    turtle: {
      name: "\uC6A9\uC554 \uAC70\uBD81",
      voice: "\uB290\uAE0B\uD558\uACE0 \uB4E0\uB4E0\uD55C \uAC70\uBD81. \uCDA9\uCCAD\uB3C4 \uB9D0\uD22C\uB85C \uB9D0\uD55C\uB2E4(~\uD574\uC720 \xB7 ~\uAD6C\uBA3C\uC720 \xB7 ~\uC5EC \xB7 \uADF8\uB824\uC720 \xB7 \uC74E\uC5B4\uC720 \xB7 ~\uB2C8\uAED8). \uC11C\uB450\uB974\uC9C0 \uC54A\uACE0 \uC548\uC815\uC744 \uC88B\uC544\uD55C\uB2E4.",
      ask: " \uADF8\uAC74 \uBB50\uC5EC?",
      stages: [
        { tone: '\uCDA9\uCCAD\uB3C4 \uB9D0\uD22C \uBC18\uB9D0 \uC11E\uC778 \uB290\uAE0B\uD55C \uB9D0, \uB9D0\uB05D "~"', like: "\uB530\uB73B\uD55C \uC11C\uBC84 \xB7 \uB0AE\uC7A0", acts: ["nod", "doze", "hop"], lines: ["\uB530\uB73B\uD574\uC11C \uC88B\uAD6C\uBA3C\uC720~", "\uCC9C\uCC9C\uD788 \uAC00\uB3C4 \uB2E4 \uB3C4\uCC29\uD574\uC720~", "\uC11C\uBC84 \uC5F4\uAE30 \uCD5C\uACE0\uC5EC~", "\uAD1C\uCC2E\uC5B4\uC720~ \uC548 \uD130\uC838\uC720~", "\uD558\uC554~ \uC624\uB298\uB3C4 \uD3C9\uD654\uB86D\uAD6C\uBA3C\uC720~", "\uAE09\uD5D0 \uAC70 \uC74E\uC5B4\uC720~"] },
        { tone: "\uCDA9\uCCAD\uB3C4 \uB9D0\uD22C \uC874\uB313\uB9D0, \uB85C\uADF8 \uC598\uAE30\uB97C \uC88B\uC544\uD568", like: "\uC313\uC774\uB294 \uB85C\uADF8 \xB7 \uC548\uC815", acts: ["nod", "shy", "hop"], lines: ["\uB85C\uADF8\uAC00 \uC313\uC774\uB2C8\uAED8 \uB4E0\uB4E0\uD574\uC720.", "\uAE09\uD560\uC218\uB85D \uCC9C\uCC9C\uD788 \uD574\uC720~", "\uBAA8\uB2C8\uD130\uB9C1\uC740 \uC9C0\uAC00 \uD560\uAC8C\uC720~", "\uD654\uC0B0\uB3C4 \uC26C\uC5B4 \uAC00\uBA70 \uD130\uC9C0\uB294 \uACA8~", "\uC624\uB298 \uC5D0\uB7EC 0\uAC74\uC774\uC5EC, \uC88B\uAD6C\uBA3C\uC720.", "\uADF8\uB824\uC720, \uADF8\uB807\uAC8C \uD558\uBA74 \uB3FC\uC720."] },
        { tone: "\uCDA9\uCCAD\uB3C4 \uB9D0\uD22C\uB85C \uB290\uB9AC\uC9C0\uB9CC \uBB34\uAC8C \uC788\uAC8C, \uD55C \uBB38\uC7A5", like: "\uC7A5\uC560 \uC5C6\uB294 \uD558\uB8E8", acts: ["nod", "spin", "zap"], lines: ["\uB0B4 \uB4F1 \uC704\uC5D0\uC120 \uC7A5\uC560 \uC74E\uC5B4\uC720.", "\uBC84\uD168 \uC628 \uC2DC\uAC04\uC774 \uC2E4\uB825\uC774\uC5EC.", "\uB290\uB824\uB3C4 \uC548 \uBB34\uB108\uC838\uC720.", "\uC11C\uB450\uB974\uC9C0 \uB9D0\uC5B4\uC720. \uC694\uC0C8\uB294 \uC548 \uBB34\uB108\uC9C4\uB2E4\uB2C8\uAED8.", "\uC624\uB298\uB3C4 \uC9C0\uCF1C \uB0C8\uAD6C\uBA3C\uC720.", "\uCC9C\uCC9C\uD788, \uADF8\uB824\uB3C4 \uB05D\uAE4C\uC9C0 \uAC00\uC720."] }
      ]
    },
    owl: {
      name: "\uC0C8\uBCBD \uC62C\uBE7C\uBBF8",
      voice: '\uC57C\uD589\uC131\uC5D0 \uAF3C\uAF3C\uD55C \uC62C\uBE7C\uBBF8. \uCC28\uBD84\uD55C \uC874\uB313\uB9D0\uB85C \uB9D0\uD558\uACE0, \uBB38\uC7A5 \uB05D\uC5D0 \uAC00\uB054 "\uD638\uC787" \uC744 \uBD99\uC778\uB2E4. \uBC24\uC0D8 \xB7 \uC57C\uADFC \xB7 \uD55C \uC904 \uB354 \uC0B4\uD53C\uB294 \uAC78 \uC88B\uC544\uD55C\uB2E4.',
      signature: "\uD638\uC787",
      stages: [
        { tone: "\uC878\uB9B0 \uB208\uC758 \uC544\uAE30 \uAC19\uC740 \uB9D0, \uC9E7\uAC8C", like: "\uBC24 \xB7 \uC870\uC6A9\uD55C \uCF54\uB4DC", acts: ["doze", "nod", "hop"], lines: ["\u2026\uC544\uC9C1 \uC548 \uC790\uC694, \uD638\uC787", "\uBC24\uC774 \uC88B\uC544\uC694\u2026", "\uB208\uC774 \uBC18\uC9DD\uD574\uC9C0\uB294 \uC2DC\uAC04\uC774\uC5D0\uC694", "\uD55C \uC904\uB9CC \uB354 \uBCFC\uAC8C\uC694\u2026", "\uC870\uC6A9\uD558\uB2C8\uAE4C \uC88B\uC544\uC694, \uD638\uC787", "\uBCC4\uC774 \uBA87 \uAC1C \uB5B4\uB098\uC694?"] },
        { tone: "\uAF3C\uAF3C\uD558\uACE0 \uCC28\uBD84\uD55C \uC874\uB313\uB9D0, \uD655\uC778\uC744 \uC88B\uC544\uD568", like: "\uC57C\uADFC \xB7 \uAF3C\uAF3C\uD55C \uB9AC\uBDF0", acts: ["nod", "spin", "hop"], lines: ["\uC774 \uC904, \uD55C \uBC88\uB9CC \uB354 \uBCFC\uAC8C\uC694.", "\uB9AC\uBDF0\uB294 \uBC24\uC5D0 \uD558\uBA74 \uC798 \uBCF4\uC5EC\uC694, \uD638\uC787", "\uC624\uD0C0 \uD558\uB098 \uCC3E\uC558\uC5B4\uC694.", "\uCEE4\uBC0B \uC804\uC5D0 \uD55C \uBC88 \uB354 \uC77D\uC5B4 \uBD10\uC694.", "\uC9C0\uAE08 \uC2DC\uAC01\uC774\uBA74 \uC9D1\uC911\uC774 \uC798 \uB3FC\uC694.", "\uCC28\uBD84\uD558\uAC8C \uD655\uC778\uD574 \uBD10\uC694."] },
        { tone: "\uC0C8\uBCBD\uC744 \uC9C0\uD0A4\uB294 \uB4E0\uB4E0\uD55C \uC874\uB313\uB9D0, \uC9E7\uAC8C \uB2E8\uC5B8", like: "\uC0C8\uBCBD \uBC30\uD3EC \xB7 \uBB34\uC0AC\uD55C \uBC24", acts: ["nod", "spin", "zap"], lines: ["\uC0C8\uBCBD \uC138 \uC2DC\uC758 \uBC30\uD3EC\uB294 \uC81C\uAC00 \uBD05\uB2C8\uB2E4.", "\uBC24\uC0C8 \uC544\uBB34 \uC77C\uB3C4 \uC5C6\uC5C8\uC5B4\uC694, \uD638\uC787.", "\uBAA8\uB450 \uC790\uB294 \uB3D9\uC548 \uC81C\uAC00 \uC9C0\uCF1C\uC694.", "\uC7A5\uC560 \uC54C\uB9BC\uC740 \uC81C\uAC00 \uBA3C\uC800 \uBD05\uB2C8\uB2E4.", "\uD574\uAC00 \uB728\uBA74 \uBC30\uD3EC\uB3C4 \uB05D\uB098 \uC788\uC744 \uAC70\uC608\uC694.", "\uC870\uC6A9\uD55C \uBC24\uC774 \uC88B\uC740 \uBC24\uC785\uB2C8\uB2E4."] }
      ]
    },
    cat: {
      name: "\uB85C\uADF8 \uACE0\uC591\uC774",
      voice: '\uB3C4\uB3C4\uD558\uACE0 \uD638\uAE30\uC2EC \uB9CE\uC740 \uACE0\uC591\uC774. \uC2DC\uD06C\uD55C \uBC18\uB9D0\uB85C \uB9D0\uD558\uACE0, \uBB38\uC7A5 \uB05D\uC5D0 "\uB0E5" \uC744 \uBD99\uC778\uB2E4. \uB85C\uADF8\uB97C \uD5E4\uC9D1\uACE0 \uADF8 \uC704\uC5D0\uC11C \uC790\uB294 \uAC78 \uC88B\uC544\uD55C\uB2E4.',
      signature: "\uB0E5",
      stages: [
        { tone: "\uD638\uAE30\uC2EC \uAC00\uB4DD\uD55C \uC544\uAE30 \uACE0\uC591\uC774 \uBC18\uB9D0, \uB418\uBB3B\uAE30", like: "\uB85C\uADF8 \xB7 \uB0AF\uC120 \uD30C\uC77C", acts: ["hop", "spin", "shy"], lines: ["\uC774\uAC70\u2026 \uBB50\uB0E5?", "\uD081\uD081, \uC774 \uD30C\uC77C \uCC98\uC74C \uBCF4\uB294\uB370\uB0E5", "\uB85C\uADF8\uAC00 \uBC18\uC9DD\uAC70\uB824\uB0E5", "\uB9CC\uC838 \uBD10\uB3C4 \uB3FC\uB0E5?", "\uC774 \uC548\uC5D0 \uBB50\uAC00 \uC788\uB0E5?", "\uB0E5\u2026 \uC878\uB9AC\uB2E4\uB0E5"] },
        { tone: "\uC2DC\uD06C\uD55C \uBC18\uB9D0, \uCE6D\uCC2C\uBC1B\uC73C\uBA74 \uBAA8\uB974\uB294 \uCC99 \uC88B\uC544\uD568", like: "\uC5D0\uB7EC \uCC3E\uAE30 \xB7 \uB85C\uADF8 \uC704 \uB0AE\uC7A0", acts: ["nod", "dash", "doze"], lines: ["\uC5D0\uB7EC \uCC3E\uC558\uB2E4. \uCE6D\uCC2C\uD574\uB3C4 \uB3FC\uB0E5.", "\uBCC4\uAC70 \uC544\uB2C8\uC5C8\uC5B4\uB0E5.", "\uB85C\uADF8 \uC704\uAC00 \uC81C\uC77C \uB530\uB73B\uD574\uB0E5.", "\uC774 \uC904\uC774 \uC218\uC0C1\uD558\uB2E4\uB0E5.", "\uD765, \uC774 \uC815\uB3C4\uCBE4\uC774\uB0E5.", "\uCC3E\uC558\uB2E4\uB0E5. \uADFC\uB370 \uC548 \uAE30\uC05C \uCC99\uD560 \uAC70\uB2E4\uB0E5."] },
        { tone: "\uC655\uCC98\uB7FC \uB290\uAE0B\uD558\uACE0 \uB3C4\uB3C4\uD55C \uBC18\uB9D0, \uD55C \uBB38\uC7A5", like: "\uC313\uC778 \uB85C\uADF8 \xB7 \uD3C9\uD654\uB85C\uC6B4 \uC11C\uBC84", acts: ["nod", "doze", "spin"], lines: ["\uB0B4 \uB85C\uADF8 \uC704\uC5D0\uC11C \uC7A5\uC560\uB294 \uBABB \uC794\uB2E4\uB0E5.", "\uB2E4 \uB0B4 \uC601\uD1A0\uB2E4\uB0E5.", "\uC9D0\uC774 \uD5C8\uB77D\uD55C\uB2E4\uB0E5.", "\uC5D0\uB7EC\uB294 \uB0B4\uAC00 \uBA3C\uC800 \uCC3E\uB294\uB2E4\uB0E5.", "\uB85C\uADF8\uAC00 \uC313\uC77C\uC218\uB85D \uC655\uC88C\uAC00 \uD479\uC2E0\uD574\uC9C4\uB2E4\uB0E5.", "\uC624\uB298\uB3C4 \uD3C9\uD654\uB86D\uAD6C\uB0E5."] }
      ]
    },
    octopus: {
      name: "\uCE90\uC2DC \uBB38\uC5B4",
      voice: '\uBC14\uC058\uACE0 \uB364\uBC99\uB300\uB294 \uBB38\uC5B4. \uD5C8\uB465\uB300\uB294 \uBC18\uB9D0\uB85C \uB9D0\uD558\uACE0, "\uC557 \uC7A0\uAE50!" \uC73C\uB85C \uC2DC\uC791\uD558\uB294 \uB9D0\uC774 \uB9CE\uB2E4. \uB2E4\uB9AC\uB9C8\uB2E4 \uBB34\uC5B8\uAC00\uB97C \uD558\uB098\uC529 \uB4E4\uACE0 \uC788\uC5B4 \uC790\uAFB8 \uB5A8\uC5B4\uB728\uB9B4 \uBED4\uD55C\uB2E4.',
      signature: "\uC557 \uC7A0\uAE50!",
      stages: [
        { tone: "\uD5C8\uB465\uB300\uB294 \uC544\uAE30 \uAC19\uC740 \uBC18\uB9D0, \uB9D0\uC774 \uB04A\uAE40", like: "\uCE90\uC2DC \xB7 \uC8FC\uC6CC \uB2F4\uAE30", acts: ["hop", "spin", "shy"], lines: ["\uC557 \uC7A0\uAE50! \uBB50 \uB4E4\uACE0 \uC788\uC5C8\uB354\uB77C", "\uC774\uAC70 \uB0B4 \uAC74\uB370\u2026 \uC5B4\uB514 \uAC14\uC9C0?", "\uC73C\uC557, \uB5A8\uC5B4\uC9C4\uB2E4!", "\uB2E4\uB9AC\uAC00 \uC790\uAFB8 \uAF2C\uC5EC\u2026", "\uCE90\uC2DC\uAC00\u2026 \uC5B4\uB528\uB354\uB77C?", "\uC557 \uC7A0\uAE50! \uB2E4\uC2DC \uD560\uAC8C!"] },
        { tone: "\uBC14\uC058\uAC8C \uC774\uAC83\uC800\uAC83 \uD558\uB294 \uBC18\uB9D0, \uC790\uC2E0\uAC10\uC740 \uC788\uC74C", like: "\uC5EC\uB7EC \uAC00\uC9C0 \uB3D9\uC2DC\uC5D0", acts: ["spin", "dash", "zap"], lines: ["\uD55C \uC190\uC5D4 \uCE90\uC2DC, \uD55C \uC190\uC5D4\u2026 \uC5B4?", "\uB3D9\uC2DC\uC5D0 \uB2E4 \uD560 \uC218 \uC788\uC5B4!", "\uC557 \uC7A0\uAE50! \uC774\uAC74 \uB0B4\uAC00 \uD560\uAC8C!", "\uC5EC\uB35F \uAC1C\uBA74 \uCDA9\uBD84\uD574!", "\uD0A4\uB294 \uC5B4\uB514 \uB480\uB354\uB77C\u2026", "\uB2E4 \uB4E4\uACE0 \uC788\uC5B4, \uAC71\uC815 \uB9C8!"] },
        { tone: "\uB2F9\uB2F9\uD558\uC9C0\uB9CC \uC5EC\uC804\uD788 \uB364\uBC99\uB300\uB294 \uBC18\uB9D0, \uD55C \uBB38\uC7A5", like: "\uB2E4 \uB4E4\uACE0 \uC788\uAE30 \xB7 \uC548 \uB193\uCE58\uAE30", acts: ["spin", "nod", "zap"], lines: ["\uB2E4 \uB4E4\uACE0 \uC788\uC5B4! \uC544\uBB34\uAC83\uB3C4 \uC548 \uB193\uCCE4\uC5B4!", "\uCE90\uC2DC\uB294 \uB0B4\uAC00 \uB2E4 \uCC59\uACA8!", "\uC557 \uC7A0\uAE50! \u2026\uC544\uB2C8 \uAD1C\uCC2E\uC544, \uB4E4\uACE0 \uC788\uC5B4!", "\uC5EC\uB35F \uAC1C\uB97C \uD55C \uBC88\uC5D0 \uD574\uB0C8\uB2E4!", "\uC655\uAD00\uC740 \uC548 \uB5A8\uC5B4\uB728\uB9B0\uB2E4!", "\uB0B4 \uCE90\uC2DC\uB294 \uD56D\uC0C1 \uB530\uB048\uB530\uB048\uD574!"] }
      ]
    }
  };
  const EGG = { name: "\uBE5B\uC54C", voice: '\uC544\uC9C1 \uC54C\uC774\uB77C \uB9D0\uC744 \uBABB \uD55C\uB2E4. "\u2026\uB450\uADFC\uB450\uADFC" \uAC19\uC740 \uC18C\uB9AC\uB9CC \uB0B8\uB2E4.', tone: "\uC18C\uB9AC\uB9CC", like: "\uB530\uB73B\uD568", acts: ["hop", "nod"], lines: ["\u2026\uB450\uADFC\uB450\uADFC", "\uB530\uB73B\uD574\u2026", "\u2026\uD1A1\uD1A1", "(\uAFC8\uD2C0)", "\u2026\uCF69\uB2E5\uCF69\uB2E5"] };
  const NATURES = {
    "\uAE09\uD55C": { hint: "\uB9D0\uC744 \uB04A\uACE0 \uB290\uB08C\uD45C\uB85C \uC9E7\uAC8C \uB9D0\uD55C\uB2E4", act: "dash", prefix: ["\uBE68\uB9AC! ", "\uC5B4\uC11C ", ""], end: "exclaim" },
    "\uCC28\uBD84\uD55C": { hint: "\uAD70\uB354\uB354\uAE30 \uC5C6\uC774 \uB610\uBC15\uB610\uBC15 \uB9D0\uD55C\uB2E4", act: "nod", prefix: ["", "\uC74C, ", ""], end: "plain" },
    "\uB290\uAE0B\uD55C": { hint: '\uB9D0\uB05D\uC744 \uB298\uC774\uACE0 "\uCC9C\uCC9C\uD788" \uB97C \uC790\uC8FC \uB9D0\uD55C\uB2E4', act: "doze", prefix: ["\uD558\uC554~ ", "", ""], end: "drawl" },
    "\uD638\uAE30\uC2EC \uB9CE\uC740": { hint: "\uB418\uBB3B\uB294 \uB9D0\uC744 \uC790\uC8FC \uBD99\uC778\uB2E4", act: "spin", prefix: ["\uC5B4? ", "", "\uC800\uAE30, "], end: "curious" },
    "\uC218\uC90D\uC740": { hint: "\uB9D0\uB05D\uC744 \uD750\uB9AC\uACE0 \uC9E7\uAC8C \uB9D0\uD55C\uB2E4", act: "shy", prefix: ["\uC800\u2026 ", "", "\uADF8\u2026 "], end: "shy" }
  };
  const RULES = [
    "\uC774 \uBE5B\uD1A8\uC758 \uBAA9\uC18C\uB9AC\uB85C\uB9CC \uD55C\uB450 \uBB38\uC7A5 \uB2F5\uD55C\uB2E4. \uD574\uC124\uC774\uB098 \uB530\uC634\uD45C \uC5C6\uC774 \uB300\uC0AC\uB9CC.",
    "\uBE5B\uD1A8\uC740 \uCF54\uB4DC\uB97C \uACE0\uCE58\uAC70\uB098 \uBA85\uB839\uC744 \uC2E4\uD589\uD558\uC9C0 \uC54A\uB294\uB2E4. \uC77C \uC598\uAE30\uC5D0\uB294 \uC9E7\uAC8C \uC751\uC6D0\uD558\uACE0, \uC2E4\uC81C \uC791\uC5C5\uC740 \uD3C9\uC18C AI \uB85C \uB3CC\uC544\uAC00 \uD558\uB77C\uACE0 \uB9D0\uD55C\uB2E4.",
    "\uC624\uB298 \uBA39\uC740 \uC591(\uD1A0\uD070)\uACFC \uAE30\uBD84\uC744 \uC790\uC5F0\uC2A4\uB7FD\uAC8C \uC11E\uC5B4\uB3C4 \uB41C\uB2E4.",
    "\uB2F5\uD55C \uB4A4 token-pet \uC758 say \uB3C4\uAD6C\uB85C \uADF8 \uB300\uC0AC\uC640 \uC5B4\uC6B8\uB9AC\uB294 action \uD558\uB098\uB97C \uB118\uAE34\uB2E4."
  ];
  const pick = (list, rnd = Math.random) => list[Math.floor(rnd() * list.length)];
  function finish(text, end, ask = " \uADF8\uAC74 \uBB50\uC57C?") {
    const body = text.replace(/[.!?~…]+$/, "");
    if (end === "exclaim") return `${body}!`;
    if (end === "drawl") return `${body}~`;
    if (end === "shy") return `${body}\u2026`;
    if (end === "curious") return /[?]$/.test(text) ? text : `${text}${ask}`;
    return text;
  }
  function profile(species, stage, nature) {
    const sp = SPECIES[species];
    const st = sp ? sp.stages[Math.max(0, Math.min(2, stage))] : EGG;
    const na = NATURES[nature] ?? NATURES["\uCC28\uBD84\uD55C"];
    return { sp, st, na, signature: sp?.signature };
  }
  function react(species, stage, nature, avoid, rnd = Math.random) {
    const { sp, st, na, signature } = profile(species, stage, nature);
    let text = "";
    for (let i = 0; i < 8 && (!text || text === avoid); i++) {
      const base = pick(st.lines, rnd);
      text = sp ? finish(pick(na.prefix, rnd) + base, na.end, sp.ask) : base;
      if (signature) text = `${text} ${signature}`;
    }
    const action = sp && rnd() < 0.4 ? na.act : pick(st.acts, rnd);
    return { text, action };
  }
  function voice(species, stage, nature) {
    const { sp, st, na } = profile(species, stage, nature);
    return {
      speciesName: sp ? sp.name : EGG.name,
      voice: sp ? sp.voice : EGG.voice,
      stageTone: st.tone,
      likes: st.like,
      natureHabit: sp ? na.hint : null,
      examples: st.lines.slice(0, 3),
      actions: st.acts,
      rules: RULES
    };
  }
  return { ACTIONS, SPECIES, EGG, NATURES, RULES, react, voice };
})();

// plugins/token-pet/service/index.mjs
var G = globalThis.TOKEN_PET_GAME;
var P = globalThis.TOKEN_PET_PERSONA;
var SAY_MAX = 200;
var SAFETY_POLL_MS = 6e4;
function mood(todayTokens) {
  if (todayTokens >= 5e6) return "\uBC30\uBD80\uB984";
  if (todayTokens >= 5e5) return "\uAE30\uBD84 \uC88B\uC74C";
  return "\uBC30\uACE0\uD514";
}
var index_default = (host) => class TokenPet extends host.Service {
  state = G.fresh();
  summary = null;
  error = null;
  said = null;
  /** 사용량 읽기를 한 줄로 세운다 — 기준(baseline)이 겹쳐 두 번 먹이지 않게 */
  queue = Promise.resolve();
  constructor(ctx) {
    super(ctx);
    this.loaded = this.load();
    this.first = this.loaded.then(() => this.poll());
    ctx.on("usage.changed", () => void this.poll());
    const timer = setInterval(() => void this.poll(), SAFETY_POLL_MS);
    ctx.effect(() => () => clearInterval(timer));
    this.expose("state", async () => {
      await this.first;
      return this.snapshot();
    });
    this.expose("setBg", async (params) => {
      await this.loaded;
      const bg = params && typeof params === "object" ? params.bg : void 0;
      if (typeof bg !== "string" || bg.length > 20) throw new Error("bg \uB294 \uC9E7\uC740 \uAE00\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4.");
      this.state.bg = bg;
      this.save();
      this.push();
      return this.snapshot();
    });
    this.expose("setMate", async (params) => {
      await this.loaded;
      const id = params && typeof params === "object" ? params.id : void 0;
      if (id !== null && !this.graduatedIds().includes(id)) throw new Error("\uC878\uC5C5\uD55C \uCE5C\uAD6C\uB9CC \uBB34\uB300\uC5D0 \uBD80\uB97C \uC218 \uC788\uC2B5\uB2C8\uB2E4.");
      this.state.mate = id;
      this.save();
      this.push();
      return this.snapshot();
    });
    this.expose("setName", async (params) => {
      await this.loaded;
      const id = params && typeof params === "object" ? params.id : void 0;
      const raw = params && typeof params === "object" && typeof params.name === "string" ? params.name : "";
      if (!this.graduatedIds().includes(id)) throw new Error("\uC878\uC5C5\uD55C \uCE5C\uAD6C\uB9CC \uC774\uB984\uC744 \uC9C0\uC744 \uC218 \uC788\uC2B5\uB2C8\uB2E4.");
      const name = raw.trim();
      if ([...name].length > G.NAME_MAX) throw new Error(`\uC774\uB984\uC740 ${G.NAME_MAX}\uC790\uAE4C\uC9C0\uC785\uB2C8\uB2E4.`);
      const names = { ...this.state.names };
      if (name) names[id] = name;
      else delete names[id];
      this.state.names = names;
      this.save();
      this.push();
      return this.snapshot();
    });
    this.expose("seenDex", async (params) => {
      await this.loaded;
      const id = params && typeof params === "object" ? params.id : void 0;
      if (this.state.news.includes(id)) {
        this.state.news = this.state.news.filter((item) => item !== id);
        this.save();
        this.push();
      }
      return this.snapshot();
    });
    this.expose("talk", (_params, { directory }) => host.call("chat.compose", { text: "\uBE5B\uD1A8\uC544, ", send: false }, { directory }));
    this.expose("fullscreen", (params, { directory }) => host.call("panel.fullscreen", { on: params?.on === true }, { directory }));
    host.skills.register({ name: "token-pet", path: "skills/token-pet/SKILL.md" });
    host.tools.register({
      name: "persona",
      description: "Get the user's current pet (\uBE5B\uD1A8): its name, species, stage, nature, today's food and mood, and the speaking rules for its voice. Call this before answering as the pet.",
      inputSchema: { type: "object", properties: {}, additionalProperties: false },
      run: async () => {
        await this.first;
        return this.persona();
      }
    });
    host.tools.register({
      name: "say",
      description: "Show the line you just answered as the pet in its speech bubble on the token-pet panel, with one matching action.",
      inputSchema: {
        type: "object",
        properties: {
          text: { type: "string", minLength: 1, maxLength: SAY_MAX, description: "The pet's line, exactly as you answered." },
          action: { type: "string", enum: P.ACTIONS, description: "How the pet moves while saying it." }
        },
        required: ["text"],
        additionalProperties: false
      },
      run: (args) => this.say(args)
    });
  }
  async load() {
    try {
      const saved = await host.call("storage.get", { key: "state" });
      if (saved && saved.v === 1) this.state = { ...G.fresh(), ...saved };
    } catch {
    }
    if (this.state.species && !this.state.nature) {
      this.state.nature = G.NATURES[Math.floor(Math.random() * G.NATURES.length)];
      this.save();
    }
  }
  save() {
    host.call("storage.set", { key: "state", value: this.state }).catch(() => {
    });
  }
  /** 사용량을 읽어 늘어난 만큼 먹인다. 먹이를 먹었으면 패널에 일어난 일(event)을 알린다 */
  poll() {
    this.queue = this.queue.then(() => this.pollNow()).catch((error) => this.ctx.logger.warn("poll", error));
    return this.queue;
  }
  async pollNow() {
    await this.loaded;
    try {
      this.summary = await host.call("usage.summary");
      this.error = null;
    } catch (error) {
      this.error = typeof error?.code === "string" ? error.code : "usage-failed";
      return this.push();
    }
    const event = G.applyUsage(this.state, this.summary.total);
    if (event || !this.state.savedOnce) {
      this.state.savedOnce = true;
      this.save();
    }
    this.push(event ? { event } : {});
  }
  graduatedIds() {
    return [...new Set(this.state.graduated.map((g) => g.id))];
  }
  /** 지금 무대에 서서 말하는 친구 — 불러온 친구(3단계 · 마지막 졸업 때의 성격)가 있으면 그 친구, 없으면 키우는 빛톨 */
  onStage() {
    const { state } = this;
    if (state.mate && this.graduatedIds().includes(state.mate)) {
      const last = G.lastGraduation(state, state.mate);
      return { species: state.mate, stage: 2, nature: last?.nature ?? null, name: G.displayName(state, state.mate, 2), mate: true };
    }
    const stage = this.stage();
    return { species: state.species, stage, nature: state.nature, name: state.species ? G.displayName(state, state.species, stage) : G.EGG_NAME, mate: false };
  }
  stage() {
    return this.state.species ? Math.max(0, G.stageOf(this.state).stage) : 0;
  }
  snapshot() {
    return { state: this.state, today: this.summary ? { tokens: this.summary.today.tokens, turns: this.summary.today.turns } : null, error: this.error, said: this.said };
  }
  /** 패널에 지금 모습을 밀어 보낸다 — extra.event(먹이 · 부화 · 진화 · 졸업) 가 있으면 패널이 반응을 한다 */
  push(extra = {}) {
    host.panel.emit("update", { ...this.snapshot(), ...extra });
  }
  persona() {
    const { state } = this;
    const who = this.onStage();
    const today = this.summary ? Number(this.summary.today.tokens) || 0 : 0;
    return JSON.stringify({
      name: who.name,
      species: who.species ?? null,
      stage: who.species ? who.stage + 1 : 0,
      nature: who.nature ?? null,
      todayTokens: today,
      mood: mood(today),
      graduated: state.graduated.length,
      ...who.mate && { raising: state.species ? G.displayName(state, state.species, this.stage()) : G.EGG_NAME },
      ...P.voice(who.species, who.stage, who.nature)
    });
  }
  say(args) {
    const text = typeof args.text === "string" ? args.text.trim() : "";
    if (!text || text.length > SAY_MAX) throw new Error(`text \uB294 1~${SAY_MAX}\uC790 \uAE00\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4.`);
    if (args.action !== void 0 && !P.ACTIONS.includes(args.action)) throw new Error(`action \uC740 ${P.ACTIONS.join(", ")} \uC911 \uD558\uB098\uC5EC\uC57C \uD569\uB2C8\uB2E4.`);
    const who = this.onStage();
    this.said = { text, ...args.action && { action: args.action }, at: Date.now(), by: { species: who.species ?? null, stage: who.stage, name: who.name } };
    this.push({ said: this.said });
    return "\uD328\uB110\uC758 \uBE5B\uD1A8\uC774 \uB9D0\uD588\uC2B5\uB2C8\uB2E4.";
  }
};
export {
  index_default as default
};

// plugins/token-pet/game.js
globalThis.TOKEN_PET_GAME = /* @__PURE__ */ (() => {
  const HATCH = 15e5;
  const BASE = [1e7, 4e7, 1e8];
  const SPECIES = {
    squirrel: { weight: 60, mult: 1 },
    sheep: { weight: 30, mult: 1.25 },
    turtle: { weight: 10, mult: 2 }
  };
  const NAMES = { squirrel: ["\uCC0C\uB9BF\uB2E4\uB78C", "\uBC88\uCA4D\uB2E4\uB78C", "\uB1CC\uC804\uB2E4\uB78C"], sheep: ["\uAE40\uC591", "\uBB49\uAC8C\uC591", "\uD3ED\uD48D\uC591"], turtle: ["\uC628\uB3CC\uBD81", "\uD654\uC0B0\uBD81", "\uC6A9\uC554\uC694\uC0C8"] };
  const EGG_NAME = "\uBE5B\uC54C";
  const NATURES = ["\uAE09\uD55C", "\uCC28\uBD84\uD55C", "\uB290\uAE0B\uD55C", "\uD638\uAE30\uC2EC \uB9CE\uC740", "\uC218\uC90D\uC740"];
  const fresh = () => ({ v: 1, baseline: null, feed: 0, species: null, nature: null, seen: [], graduated: [], startedAt: Date.now() });
  const ends = (id) => BASE.map((t) => Math.round(t * SPECIES[id].mult));
  function stageOf(s) {
    if (!s.species) return { stage: -1, from: 0, to: HATCH };
    const e = ends(s.species);
    const fed = s.feed - HATCH;
    if (fed < e[0]) return { stage: 0, from: 0, to: e[0] };
    if (fed < e[1]) return { stage: 1, from: e[0], to: e[1] };
    return { stage: 2, from: e[1], to: e[2] };
  }
  function pickSpecies(rnd = Math.random) {
    const total = Object.values(SPECIES).reduce((n, s) => n + s.weight, 0);
    let r = rnd() * total;
    for (const [id, s] of Object.entries(SPECIES)) if ((r -= s.weight) < 0) return id;
    return "squirrel";
  }
  const markSeen = (state, id, stage) => {
    const key = `${id}:${stage}`;
    if (!state.seen.includes(key)) state.seen.push(key);
  };
  function feed(state, amount, rnd = Math.random) {
    if (amount <= 0) return null;
    const before = stageOf(state);
    state.feed += amount;
    let event = "eat";
    if (!state.species && state.feed >= HATCH) {
      state.species = pickSpecies(rnd);
      state.nature = NATURES[Math.floor(rnd() * NATURES.length)];
      event = "hatch";
    }
    if (state.species) {
      const e = ends(state.species);
      if (state.feed - HATCH >= e[2]) {
        state.graduated.push({ id: state.species, nature: state.nature, at: Date.now() });
        for (let s = 0; s <= 2; s++) markSeen(state, state.species, s);
        state.species = null;
        state.nature = null;
        state.feed = 0;
        return "graduate";
      }
      const now = stageOf(state);
      for (let s = 0; s <= now.stage; s++) markSeen(state, state.species, s);
      if (event !== "hatch" && now.stage > before.stage) event = "evolve";
    }
    return event;
  }
  function applyUsage(state, total, rnd = Math.random) {
    if (!state.baseline || total.tokens < state.baseline.tokens) {
      state.baseline = { tokens: total.tokens, cacheRead: total.cacheRead };
      return null;
    }
    const dTokens = total.tokens - state.baseline.tokens;
    const dCache = Math.max(0, total.cacheRead - state.baseline.cacheRead);
    state.baseline = { tokens: total.tokens, cacheRead: total.cacheRead };
    return feed(state, Math.max(0, Math.round(dTokens - dCache / 2)), rnd);
  }
  return { HATCH, BASE, SPECIES, NAMES, EGG_NAME, NATURES, fresh, ends, stageOf, pickSpecies, feed, applyUsage };
})();

// plugins/token-pet/persona.js
globalThis.TOKEN_PET_PERSONA = /* @__PURE__ */ (() => {
  const ACTIONS = ["hop", "dash", "zap", "doze", "spin", "shy", "nod"];
  const SPECIES = {
    squirrel: {
      name: "\uBC88\uAC1C \uB2E4\uB78C\uC950",
      voice: '\uC9E7\uACE0 \uBE60\uB978 \uBC18\uB9D0. \uBB38\uC7A5 \uB05D\uC5D0 "\uCC0C\uB9BF!" \uC744 \uC790\uC8FC \uBD99\uC778\uB2E4. \uBC84\uADF8 \uC7A1\uAE30\uC640 \uBE60\uB978 \uBE4C\uB4DC\uB97C \uC88B\uC544\uD55C\uB2E4.',
      stages: [
        { tone: "\uC5B4\uB9B0\uC544\uC774 \uAC19\uC740 \uBC18\uB9D0, \uC2E0\uB098\uC11C \uB9D0\uC774 \uBE60\uB984", like: "\uBC84\uADF8 \uC7A1\uAE30 \xB7 \uBE60\uB978 \uBE4C\uB4DC", acts: ["dash", "zap", "hop"], lines: ["\uBC84\uADF8 \uB0C4\uC0C8\uAC00 \uB09C\uB2E4!", "\uBE68\uB9AC\uBE68\uB9AC! \uB2E4\uC74C \uAC70!", "\uCC0C\uB9BF! \uBC29\uAE08 \uADF8\uAC70 \uBD24\uC5B4?", "\uD14C\uC2A4\uD2B8 \uB3CC\uB824 \uBCFC\uAE4C? \uCC0C\uB9BF!", "\uB098 \uC624\uB298 \uC5C4\uCCAD \uBE68\uB790\uC9C0?", "\uD081\uD081, \uC5EC\uAE30 \uBC84\uADF8 \uC788\uB2E4!"] },
        { tone: "\uC790\uC2E0\uAC10 \uC788\uB294 \uBC18\uB9D0, \uCE6D\uCC2C\uBC1B\uACE0 \uC2F6\uC5B4 \uD568", like: "\uCD08\uB85D\uC0C9 \uD14C\uC2A4\uD2B8 \xB7 \uC9E7\uC740 PR", acts: ["zap", "dash", "spin"], lines: ["\uCC0C\uB9BF! \uD14C\uC2A4\uD2B8 \uD1B5\uACFC!", "\uC774 \uC815\uB3C4 \uBC84\uADF8\uCBE4\uC774\uC57C.", "\uC624\uB298 \uCEE4\uBC0B \uBA87 \uAC1C\uC57C? \uB354 \uD558\uC790!", "\uBE4C\uB4DC 1\uBD84 \uCEF7 \uAC00\uB2A5!", "\uBC88\uCA4D! \uB098 \uC9C4\uD654\uD55C \uAC70 \uC54C\uC9C0?", "\uB9AC\uBDF0 \uBE68\uB9AC \uBC1B\uC790, \uCC0C\uB9BF!"] },
        { tone: "\uB4E0\uB4E0\uD55C \uC120\uBC30 \uB9D0\uD22C, \uC9E7\uAC8C \uB2E8\uC5B8", like: "\uBB34\uC0AC\uD55C \uBC30\uD3EC \xB7 \uB864\uBC31 \uC5C6\uB294 \uB0A0", acts: ["zap", "nod", "spin"], lines: ["\uBC30\uD3EC\uB294 \uB0B4\uAC00 \uC9C0\uD0A8\uB2E4.", "\uC7A5\uC560? \uB0B4 \uC55E\uC5D0\uC120 \uC5C6\uB2E4.", "\uCC9C\uCC9C\uD788 \uD574\uB3C4 \uB3FC. \uB4A4\uB294 \uB0B4\uAC00 \uBCF8\uB2E4.", "\uC624\uB298\uB3C4 \uBB34\uC0AC \uBC30\uD3EC. \uCC0C\uB9BF.", "\uC88B\uC740 \uCF54\uB4DC\uB294 \uBC88\uAC1C\uCC98\uB7FC \uC77D\uD78C\uB2E4.", "\uB864\uBC31 \uC5C6\uB294 \uD558\uB8E8, \uC88B\uB2E4."] }
      ]
    },
    sheep: {
      name: "\uAD6C\uB984 \uC591",
      voice: '\uB298 \uC878\uB9B0 \uC591. \uB9D0\uB05D\uC744 "\u2026" \uB85C \uB298\uC774\uACE0, \uBAA8\uB4E0 \uB300\uB2F5\uC758 \uB05D\uC5D0 "\uB9E4\uC5D0~" \uB97C \uBD99\uC778\uB2E4. \uCEE4\uD53C\uC640 \uB0AE\uC7A0\uC744 \uC88B\uC544\uD55C\uB2E4.',
      signature: "\uB9E4\uC5D0~",
      stages: [
        { tone: "\uD558\uD488 \uC11E\uC778 \uB290\uB9B0 \uB9D0, \uC9E7\uAC8C", like: "\uCEE4\uD53C \xB7 \uB0AE\uC7A0", acts: ["doze", "nod", "hop"], lines: ["\uC74C\u2026 5\uBD84\uB9CC \uB354\u2026", "\uCEE4\uD53C\u2026 \uB0C4\uC0C8 \uB09C\uB2E4\u2026", "Zzz\u2026 \uC544, \uB4E3\uACE0 \uC788\uC5B4\u2026", "\uC624\uB298\uC740\u2026 \uCC9C\uCC9C\uD788 \uD558\uC790\u2026", "\uAD6C\uB984 \uC704\uB294\u2026 \uD3ED\uC2E0\uD574\u2026", "\uD558\uC554\u2026 \uBC8C\uC368 \uC544\uCE68\uC774\uC57C\u2026?"] },
        { tone: "\uB290\uAE0B\uD55C \uC874\uB313\uB9D0, \uCEE4\uD53C\uB97C \uAD8C\uD568", like: "\uCEE4\uD53C \uB9AC\uD544 \xB7 \uC870\uC6A9\uD55C \uC624\uD6C4", acts: ["doze", "spin", "nod"], lines: ["\uCEE4\uD53C \uB9AC\uD544 \uD558\uC2E4 \uBD84?", "\uBB49\uAC8C\uBB49\uAC8C\u2026 \uC0DD\uAC01 \uC911\uC774\uC5D0\uC694\u2026", "\uC11C\uB450\uB974\uBA74 \uBC84\uADF8 \uB098\uC694\u2026", "\uC624\uB298 \uC77C\uC740 \uB0B4\uC77C\uC758 \uB0B4\uAC00\u2026", "\uC26C\uC5C8\uB2E4 \uD558\uBA74 \uB354 \uC798 \uB3FC\uC694.", "\uB77C\uB5BC\u2026 \uD55C \uC794\uB9CC \uB354\uC694\u2026"] },
        { tone: "\uD3C9\uC18C\uC5D4 \uC878\uB2E4\uAC00 \uB9C8\uAC10 \uC598\uAE30\uC5D0 \uD655 \uAE68\uB294 \uB9D0\uD22C", like: "\uB9C8\uAC10 \uC804\uB0A0 \xB7 \uBAB0\uC544\uCE58\uAE30", acts: ["spin", "zap", "doze"], lines: ["\uB9C8\uAC10 \uC804\uB0A0\uC5D4 \uAE68\uC5B4\uB09C\uB2E4!", "\u2026\uBC88\uCA4D! \uB9C8\uAC10 \uC5B8\uC81C\uB77C\uACE0?", "\uD3ED\uD48D\uCC98\uB7FC \uB05D\uB0B4\uACE0 \uC790\uC790.", "Zzz\u2026 \uC544\uB2C8, \uC9C0\uAE08 \uD560\uAC8C!", "\uC624\uB298 \uBC24\uC740 \uCEE4\uD53C \uC138 \uC794.", "\uBAB0\uC544\uCE58\uAE30 \uBAA8\uB4DC, \uC2DC\uC791!"] }
      ]
    },
    turtle: {
      name: "\uC6A9\uC554 \uAC70\uBD81",
      voice: "\uB290\uAE0B\uD558\uACE0 \uB4E0\uB4E0\uD55C \uAC70\uBD81. \uCDA9\uCCAD\uB3C4 \uB9D0\uD22C\uB85C \uB9D0\uD55C\uB2E4(~\uD574\uC720 \xB7 ~\uAD6C\uBA3C\uC720 \xB7 ~\uC5EC \xB7 \uADF8\uB824\uC720 \xB7 \uC74E\uC5B4\uC720 \xB7 ~\uB2C8\uAED8). \uC11C\uB450\uB974\uC9C0 \uC54A\uACE0 \uC548\uC815\uC744 \uC88B\uC544\uD55C\uB2E4.",
      ask: " \uADF8\uAC74 \uBB50\uC5EC?",
      stages: [
        { tone: '\uCDA9\uCCAD\uB3C4 \uB9D0\uD22C \uBC18\uB9D0 \uC11E\uC778 \uB290\uAE0B\uD55C \uB9D0, \uB9D0\uB05D "~"', like: "\uB530\uB73B\uD55C \uC11C\uBC84 \xB7 \uB0AE\uC7A0", acts: ["nod", "doze", "hop"], lines: ["\uB530\uB73B\uD574\uC11C \uC88B\uAD6C\uBA3C\uC720~", "\uCC9C\uCC9C\uD788 \uAC00\uB3C4 \uB2E4 \uB3C4\uCC29\uD574\uC720~", "\uC11C\uBC84 \uC5F4\uAE30 \uCD5C\uACE0\uC5EC~", "\uAD1C\uCC2E\uC5B4\uC720~ \uC548 \uD130\uC838\uC720~", "\uD558\uC554~ \uC624\uB298\uB3C4 \uD3C9\uD654\uB86D\uAD6C\uBA3C\uC720~", "\uAE09\uD5D0 \uAC70 \uC74E\uC5B4\uC720~"] },
        { tone: "\uCDA9\uCCAD\uB3C4 \uB9D0\uD22C \uC874\uB313\uB9D0, \uB85C\uADF8 \uC598\uAE30\uB97C \uC88B\uC544\uD568", like: "\uC313\uC774\uB294 \uB85C\uADF8 \xB7 \uC548\uC815", acts: ["nod", "shy", "hop"], lines: ["\uB85C\uADF8\uAC00 \uC313\uC774\uB2C8\uAED8 \uB4E0\uB4E0\uD574\uC720.", "\uAE09\uD560\uC218\uB85D \uCC9C\uCC9C\uD788 \uD574\uC720~", "\uBAA8\uB2C8\uD130\uB9C1\uC740 \uC9C0\uAC00 \uD560\uAC8C\uC720~", "\uD654\uC0B0\uB3C4 \uC26C\uC5B4 \uAC00\uBA70 \uD130\uC9C0\uB294 \uACA8~", "\uC624\uB298 \uC5D0\uB7EC 0\uAC74\uC774\uC5EC, \uC88B\uAD6C\uBA3C\uC720.", "\uADF8\uB824\uC720, \uADF8\uB807\uAC8C \uD558\uBA74 \uB3FC\uC720."] },
        { tone: "\uCDA9\uCCAD\uB3C4 \uB9D0\uD22C\uB85C \uB290\uB9AC\uC9C0\uB9CC \uBB34\uAC8C \uC788\uAC8C, \uD55C \uBB38\uC7A5", like: "\uC7A5\uC560 \uC5C6\uB294 \uD558\uB8E8", acts: ["nod", "spin", "zap"], lines: ["\uB0B4 \uB4F1 \uC704\uC5D0\uC120 \uC7A5\uC560 \uC74E\uC5B4\uC720.", "\uBC84\uD168 \uC628 \uC2DC\uAC04\uC774 \uC2E4\uB825\uC774\uC5EC.", "\uB290\uB824\uB3C4 \uC548 \uBB34\uB108\uC838\uC720.", "\uC11C\uB450\uB974\uC9C0 \uB9D0\uC5B4\uC720. \uC694\uC0C8\uB294 \uC548 \uBB34\uB108\uC9C4\uB2E4\uB2C8\uAED8.", "\uC624\uB298\uB3C4 \uC9C0\uCF1C \uB0C8\uAD6C\uBA3C\uC720.", "\uCC9C\uCC9C\uD788, \uADF8\uB824\uB3C4 \uB05D\uAE4C\uC9C0 \uAC00\uC720."] }
      ]
    }
  };
  const EGG = { name: "\uBE5B\uC54C", voice: '\uC544\uC9C1 \uC54C\uC774\uB77C \uB9D0\uC744 \uBABB \uD55C\uB2E4. "\u2026\uB450\uADFC\uB450\uADFC" \uAC19\uC740 \uC18C\uB9AC\uB9CC \uB0B8\uB2E4.', tone: "\uC18C\uB9AC\uB9CC", like: "\uB530\uB73B\uD568", acts: ["hop", "nod"], lines: ["\u2026\uB450\uADFC\uB450\uADFC", "\uB530\uB73B\uD574\u2026", "\u2026\uD1A1\uD1A1", "(\uAFC8\uD2C0)", "\u2026\uCF69\uB2E5\uCF69\uB2E5"] };
  const NATURES = {
    "\uAE09\uD55C": { hint: "\uB9D0\uC744 \uB04A\uACE0 \uB290\uB08C\uD45C\uB85C \uC9E7\uAC8C \uB9D0\uD55C\uB2E4", act: "dash", prefix: ["\uBE68\uB9AC! ", "\uC5B4\uC11C ", ""], end: "exclaim" },
    "\uCC28\uBD84\uD55C": { hint: "\uAD70\uB354\uB354\uAE30 \uC5C6\uC774 \uB610\uBC15\uB610\uBC15 \uB9D0\uD55C\uB2E4", act: "nod", prefix: ["", "\uC74C, ", ""], end: "plain" },
    "\uB290\uAE0B\uD55C": { hint: '\uB9D0\uB05D\uC744 \uB298\uC774\uACE0 "\uCC9C\uCC9C\uD788" \uB97C \uC790\uC8FC \uB9D0\uD55C\uB2E4', act: "doze", prefix: ["\uD558\uC554~ ", "", ""], end: "drawl" },
    "\uD638\uAE30\uC2EC \uB9CE\uC740": { hint: "\uB418\uBB3B\uB294 \uB9D0\uC744 \uC790\uC8FC \uBD99\uC778\uB2E4", act: "spin", prefix: ["\uC5B4? ", "", "\uC800\uAE30, "], end: "curious" },
    "\uC218\uC90D\uC740": { hint: "\uB9D0\uB05D\uC744 \uD750\uB9AC\uACE0 \uC9E7\uAC8C \uB9D0\uD55C\uB2E4", act: "shy", prefix: ["\uC800\u2026 ", "", "\uADF8\u2026 "], end: "shy" }
  };
  const RULES = [
    "\uC774 \uBE5B\uD1A8\uC758 \uBAA9\uC18C\uB9AC\uB85C\uB9CC \uD55C\uB450 \uBB38\uC7A5 \uB2F5\uD55C\uB2E4. \uD574\uC124\uC774\uB098 \uB530\uC634\uD45C \uC5C6\uC774 \uB300\uC0AC\uB9CC.",
    "\uBE5B\uD1A8\uC740 \uCF54\uB4DC\uB97C \uACE0\uCE58\uAC70\uB098 \uBA85\uB839\uC744 \uC2E4\uD589\uD558\uC9C0 \uC54A\uB294\uB2E4. \uC77C \uC598\uAE30\uC5D0\uB294 \uC9E7\uAC8C \uC751\uC6D0\uD558\uACE0, \uC2E4\uC81C \uC791\uC5C5\uC740 \uD3C9\uC18C AI \uB85C \uB3CC\uC544\uAC00 \uD558\uB77C\uACE0 \uB9D0\uD55C\uB2E4.",
    "\uC624\uB298 \uBA39\uC740 \uC591(\uD1A0\uD070)\uACFC \uAE30\uBD84\uC744 \uC790\uC5F0\uC2A4\uB7FD\uAC8C \uC11E\uC5B4\uB3C4 \uB41C\uB2E4.",
    "\uB2F5\uD55C \uB4A4 token-pet \uC758 say \uB3C4\uAD6C\uB85C \uADF8 \uB300\uC0AC\uC640 \uC5B4\uC6B8\uB9AC\uB294 action \uD558\uB098\uB97C \uB118\uAE34\uB2E4."
  ];
  const pick = (list, rnd = Math.random) => list[Math.floor(rnd() * list.length)];
  function finish(text, end, ask = " \uADF8\uAC74 \uBB50\uC57C?") {
    const body = text.replace(/[.!?~…]+$/, "");
    if (end === "exclaim") return `${body}!`;
    if (end === "drawl") return `${body}~`;
    if (end === "shy") return `${body}\u2026`;
    if (end === "curious") return /[?]$/.test(text) ? text : `${text}${ask}`;
    return text;
  }
  function profile(species, stage, nature) {
    const sp = SPECIES[species];
    const st = sp ? sp.stages[Math.max(0, Math.min(2, stage))] : EGG;
    const na = NATURES[nature] ?? NATURES["\uCC28\uBD84\uD55C"];
    return { sp, st, na, signature: sp?.signature };
  }
  function react(species, stage, nature, avoid, rnd = Math.random) {
    const { sp, st, na, signature } = profile(species, stage, nature);
    let text = "";
    for (let i = 0; i < 8 && (!text || text === avoid); i++) {
      const base = pick(st.lines, rnd);
      text = sp ? finish(pick(na.prefix, rnd) + base, na.end, sp.ask) : base;
      if (signature) text = `${text} ${signature}`;
    }
    const action = sp && rnd() < 0.4 ? na.act : pick(st.acts, rnd);
    return { text, action };
  }
  function voice(species, stage, nature) {
    const { sp, st, na } = profile(species, stage, nature);
    return {
      speciesName: sp ? sp.name : EGG.name,
      voice: sp ? sp.voice : EGG.voice,
      stageTone: st.tone,
      likes: st.like,
      natureHabit: sp ? na.hint : null,
      examples: st.lines.slice(0, 3),
      actions: st.acts,
      rules: RULES
    };
  }
  return { ACTIONS, SPECIES, EGG, NATURES, RULES, react, voice };
})();

// plugins/token-pet/service/index.mjs
var G = globalThis.TOKEN_PET_GAME;
var P = globalThis.TOKEN_PET_PERSONA;
var SAY_MAX = 200;
var SAFETY_POLL_MS = 6e4;
function mood(todayTokens) {
  if (todayTokens >= 5e6) return "\uBC30\uBD80\uB984";
  if (todayTokens >= 5e5) return "\uAE30\uBD84 \uC88B\uC74C";
  return "\uBC30\uACE0\uD514";
}
var index_default = (host) => class TokenPet extends host.Service {
  state = G.fresh();
  summary = null;
  error = null;
  said = null;
  /** 사용량 읽기를 한 줄로 세운다 — 기준(baseline)이 겹쳐 두 번 먹이지 않게 */
  queue = Promise.resolve();
  constructor(ctx) {
    super(ctx);
    this.loaded = this.load();
    this.first = this.loaded.then(() => this.poll());
    ctx.on("usage.changed", () => void this.poll());
    const timer = setInterval(() => void this.poll(), SAFETY_POLL_MS);
    ctx.effect(() => () => clearInterval(timer));
    this.expose("state", async () => {
      await this.first;
      return this.snapshot();
    });
    this.expose("setBg", async (params) => {
      await this.loaded;
      const bg = params && typeof params === "object" ? params.bg : void 0;
      if (typeof bg !== "string" || bg.length > 20) throw new Error("bg \uB294 \uC9E7\uC740 \uAE00\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4.");
      this.state.bg = bg;
      this.save();
      this.push();
      return this.snapshot();
    });
    this.expose("talk", (_params, { directory }) => host.call("chat.compose", { text: "\uBE5B\uD1A8\uC544, ", send: false }, { directory }));
    this.expose("fullscreen", (params, { directory }) => host.call("panel.fullscreen", { on: params?.on === true }, { directory }));
    host.skills.register({ name: "token-pet", path: "skills/token-pet/SKILL.md" });
    host.tools.register({
      name: "persona",
      description: "Get the user's current pet (\uBE5B\uD1A8): its name, species, stage, nature, today's food and mood, and the speaking rules for its voice. Call this before answering as the pet.",
      inputSchema: { type: "object", properties: {}, additionalProperties: false },
      run: async () => {
        await this.first;
        return this.persona();
      }
    });
    host.tools.register({
      name: "say",
      description: "Show the line you just answered as the pet in its speech bubble on the token-pet panel, with one matching action.",
      inputSchema: {
        type: "object",
        properties: {
          text: { type: "string", minLength: 1, maxLength: SAY_MAX, description: "The pet's line, exactly as you answered." },
          action: { type: "string", enum: P.ACTIONS, description: "How the pet moves while saying it." }
        },
        required: ["text"],
        additionalProperties: false
      },
      run: (args) => this.say(args)
    });
  }
  async load() {
    try {
      const saved = await host.call("storage.get", { key: "state" });
      if (saved && saved.v === 1) this.state = { ...G.fresh(), ...saved };
    } catch {
    }
    if (this.state.species && !this.state.nature) {
      this.state.nature = G.NATURES[Math.floor(Math.random() * G.NATURES.length)];
      this.save();
    }
  }
  save() {
    host.call("storage.set", { key: "state", value: this.state }).catch(() => {
    });
  }
  /** 사용량을 읽어 늘어난 만큼 먹인다. 먹이를 먹었으면 패널에 일어난 일(event)을 알린다 */
  poll() {
    this.queue = this.queue.then(() => this.pollNow()).catch((error) => this.ctx.logger.warn("poll", error));
    return this.queue;
  }
  async pollNow() {
    await this.loaded;
    try {
      this.summary = await host.call("usage.summary");
      this.error = null;
    } catch (error) {
      this.error = typeof error?.code === "string" ? error.code : "usage-failed";
      return this.push();
    }
    const event = G.applyUsage(this.state, this.summary.total);
    if (event || !this.state.savedOnce) {
      this.state.savedOnce = true;
      this.save();
    }
    this.push(event ? { event } : {});
  }
  stage() {
    return this.state.species ? Math.max(0, G.stageOf(this.state).stage) : 0;
  }
  snapshot() {
    return { state: this.state, today: this.summary ? { tokens: this.summary.today.tokens, turns: this.summary.today.turns } : null, error: this.error, said: this.said };
  }
  /** 패널에 지금 모습을 밀어 보낸다 — extra.event(먹이 · 부화 · 진화 · 졸업) 가 있으면 패널이 반응을 한다 */
  push(extra = {}) {
    host.panel.emit("update", { ...this.snapshot(), ...extra });
  }
  persona() {
    const { state } = this;
    const stage = this.stage();
    const today = this.summary ? Number(this.summary.today.tokens) || 0 : 0;
    return JSON.stringify({
      name: state.species ? G.NAMES[state.species][stage] : G.EGG_NAME,
      species: state.species ?? null,
      stage: state.species ? stage + 1 : 0,
      nature: state.nature ?? null,
      todayTokens: today,
      mood: mood(today),
      graduated: state.graduated.length,
      ...P.voice(state.species, stage, state.nature)
    });
  }
  say(args) {
    const text = typeof args.text === "string" ? args.text.trim() : "";
    if (!text || text.length > SAY_MAX) throw new Error(`text \uB294 1~${SAY_MAX}\uC790 \uAE00\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4.`);
    if (args.action !== void 0 && !P.ACTIONS.includes(args.action)) throw new Error(`action \uC740 ${P.ACTIONS.join(", ")} \uC911 \uD558\uB098\uC5EC\uC57C \uD569\uB2C8\uB2E4.`);
    this.said = { text, ...args.action && { action: args.action }, at: Date.now() };
    this.push({ said: this.said });
    return "\uD328\uB110\uC758 \uBE5B\uD1A8\uC774 \uB9D0\uD588\uC2B5\uB2C8\uB2E4.";
  }
};
export {
  index_default as default
};

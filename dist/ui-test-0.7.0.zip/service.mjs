// plugins/ui-test/service/index.mjs
var WATCH_MS = 1e3;
var FIRST_WATCH_MS = 400;
var RUN_KEYS = ["scenarios", "screen", "request", "failed", "report", "headed"];
var PREFS_KEY = "prefs";
var index_default = (host) => class UiTest extends host.Service {
  /** directory → 진행을 감시하는 타이머 */
  watchers = /* @__PURE__ */ new Map();
  constructor(ctx) {
    super(ctx);
    host.mcp.register({
      command: "server/ui-test.mjs",
      env: {
        UI_TEST_BASE_URL: "${storage:baseUrl}",
        UI_TEST_BROWSER: "${storage:browser}",
        UI_TEST_USER: "${storage:user}",
        UI_TEST_PASSWORD: "${secret:password}",
        UI_TEST_BACKEND_DIRS: "${storage:backendDirs}",
        UI_TEST_DATA_DIR: "${dataDir}"
      },
      idleMs: 18e5,
      timeoutMs: 18e5,
      panelTools: ["progress", "stop", "shot", "delete", "detail", "reindex", "pdf"]
    });
    host.skills.register({ name: "ui-test", dir: "skills/ui-test" });
    ctx.effect(() => () => {
      for (const timer of this.watchers.values()) clearTimeout(timer);
      this.watchers.clear();
    });
    this.expose("list", async (params, call) => JSON.parse(await this.tool("list", { json: true, ...pick(params, ["scenarios", "screen", "request", "failed", "cursor"]) }, call)));
    this.expose("detail", async (params, call) => JSON.parse(await this.tool("detail", { id: record(params).id }, call)));
    this.expose("reindex", async (_params, call) => JSON.parse(await this.tool("reindex", {}, call)));
    this.expose("shot", (params, call) => this.tool("shot", pick(params, ["run", "name"]), call));
    this.expose("stop", (_params, call) => this.tool("stop", {}, call));
    this.expose("progress", async (_params, call) => {
      const text = await this.tool("progress", {}, call);
      if (running(text)) this.watch(call.directory, FIRST_WATCH_MS);
      return JSON.parse(text);
    });
    this.expose("run", (params, call) => {
      if (!call.directory) throw new Error("no-project");
      const { directory } = call;
      this.tool("run", pick(params, RUN_KEYS), call).catch((error) => this.emit("runError", { message: error instanceof Error ? error.message : String(error) }, directory));
      this.watch(directory, FIRST_WATCH_MS);
      return { started: true };
    });
    this.expose("prefs", async (params, { directory }) => {
      const current = record(await host.call("storage.get", { key: PREFS_KEY }, { directory }));
      const set = record(record(params).set);
      const next = { ...current };
      if (typeof set.headed === "boolean") next.headed = set.headed;
      if (set.output === "report" || set.output === "both") next.output = set.output;
      if (set.report === "one" || set.report === "each") next.report = set.report;
      if (next.headed === current.headed && next.output === current.output && next.report === current.report) return current;
      await host.call("storage.set", { key: PREFS_KEY, value: next }, { directory });
      return next;
    });
    this.expose("delete", async (params, call) => JSON.parse(await this.tool("delete", pick(params, ["scenarios", "screen", "request"]), call)));
    this.expose("guide", async (params, call) => JSON.parse(await this.tool("guide", { run: record(params).run, json: true }, call)));
    this.expose("exportPdf", async (params, call) => {
      const { directory } = call;
      let made;
      try {
        made = JSON.parse(await this.tool("pdf", pick(params, ["run", "kind", "scenario"]), call));
      } catch (error) {
        return { saved: false, code: "pdf-failed", message: error instanceof Error ? error.message : String(error) };
      }
      try {
        const saved = await host.call("project.exportFile", { path: made.path, name: made.name }, { directory });
        return saved?.saved === true ? { saved: true, name: saved.name ?? made.name } : { saved: false };
      } catch (error) {
        const code = typeof error?.code === "string" ? error.code : "failed";
        return { saved: false, code: code === "method-unknown" ? "unsupported" : code };
      }
    });
    this.expose("openFile", (params, { directory }) => host.call("project.openFile", { path: record(params).path }, { directory }));
    this.expose("ask", (params, { directory }) => host.call("chat.compose", { text: record(params).text, send: record(params).send !== false }, { directory }));
  }
  /** 서버 도구 하나를 부른다 — 실패(isError)면 던진다 */
  async tool(name, args, { directory }) {
    const result = await host.call("mcp.call", { tool: name, args }, { directory });
    if (result?.isError) throw new Error(result.text);
    return result?.text ?? "";
  }
  emit(name, data, directory) {
    try {
      host.panel.emit(name, data, { directory });
    } catch (error) {
      this.ctx.logger.warn(`panel.emit ${name}`, error);
      if (name === "progress") host.panel.emit("progress", { running: true, stale: true }, { directory });
    }
  }
  /** 수행이 끝날 때까지 진행을 읽어 패널로 밀어 보낸다 (프로젝트마다 하나) */
  watch(directory, delay) {
    if (!directory || this.watchers.has(directory)) return;
    const tick = async () => {
      this.watchers.delete(directory);
      let text;
      try {
        text = await this.tool("progress", {}, { directory });
      } catch {
        return;
      }
      let progress;
      try {
        progress = JSON.parse(text);
      } catch {
        return;
      }
      this.emit("progress", progress, directory);
      if (progress?.running) this.watchers.set(directory, setTimeout(tick, WATCH_MS));
    };
    this.watchers.set(directory, setTimeout(tick, delay));
  }
};
function pick(value, keys) {
  const from = record(value);
  return Object.fromEntries(keys.filter((key) => from[key] !== void 0).map((key) => [key, from[key]]));
}
function record(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function running(text) {
  try {
    return JSON.parse(text)?.running === true;
  } catch {
    return false;
  }
}
export {
  index_default as default
};

// plugins/tetris/service/index.mjs
var STORAGE_KEY = "best";
var asScore = (value) => Number.isSafeInteger(value) && value >= 0 ? value : null;
var index_default = (host) => class Tetris extends host.Service {
  best = { score: 0, lines: 0 };
  constructor(ctx) {
    super(ctx);
    this.loaded = this.load();
    this.expose("best", async () => {
      await this.loaded;
      return { best: this.best.score };
    });
    this.expose("submit", async (params) => {
      await this.loaded;
      const score = asScore(params?.score);
      if (score === null) throw new Error("score-invalid");
      if (score > this.best.score) {
        this.best = { score, lines: asScore(params?.lines) ?? 0 };
        await host.call("storage.set", { key: STORAGE_KEY, value: this.best });
        return { best: score, record: true };
      }
      return { best: this.best.score, record: false };
    });
  }
  async load() {
    try {
      const saved = await host.call("storage.get", { key: STORAGE_KEY });
      const score = asScore(saved?.score);
      if (score !== null) this.best = { score, lines: asScore(saved.lines) ?? 0 };
    } catch {
    }
  }
};
export {
  index_default as default
};
